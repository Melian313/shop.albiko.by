<?php

if (Core_Array::getRequest('_', FALSE))
{
	$iMaillistId = intval(Core_Array::getGet('maillist_id'));
	$iType = Core_Array::getGet('type', 0);

	$oSiteuser = Core_Entity::factory('Siteuser')->getCurrent();

	$result = "Error";
	if (!is_null($oSiteuser))
	{
		$aMaillists = $oSiteuser->getAllowedMaillists();
		foreach ($aMaillists as $oMaillist)
		{
			if ($oMaillist->id == $iMaillistId)
			{
				$oMaillist_Siteuser = $oSiteuser->Maillist_Siteusers->getByMaillist($oMaillist->id);

				// ������������ �� ��������
				if (is_null($oMaillist_Siteuser))
				{
					// ������������ �� ��� ��������
					 $oMaillist_Siteuser = Core_Entity::factory('Maillist_Siteuser')
						->siteuser_id($oSiteuser->id)
						->maillist_id($oMaillist->id);

					$oMaillist_Siteuser->type = $iType == 0 ? 0 : 1;
					$oMaillist_Siteuser->save();

					$result = "OK";
					break;
				}
				else
				{
					$result = "Already subscribed";
				}
			}
		}
	}

	echo json_encode($result);
	exit();
}